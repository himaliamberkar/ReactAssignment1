import React from 'react';
import MyListComponent from './components/MyListComponent';
import "bootstrap/dist/css/bootstrap.min.css";


const App = () => {
  return (
      <MyListComponent />
  );
};

export default App;


